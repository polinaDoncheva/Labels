package fmi.designpatterns.labels;

public interface Label {
    String getText();
}
