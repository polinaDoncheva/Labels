package fmi.designpatterns.labels.helpLabels;

public interface HelpLabel {

    String getHelp();
}
