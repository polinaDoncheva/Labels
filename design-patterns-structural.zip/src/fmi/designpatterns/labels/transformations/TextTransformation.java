package fmi.designpatterns.labels.transformations;

public interface TextTransformation {
    String transform(String text);
}
